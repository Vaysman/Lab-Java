package ru.bstu.itz51.Shulpekov.lab3;

        import java.util.Scanner;
        import java.io.*;
        import java.util.regex.Matcher;
        import java.util.regex.Pattern;
public class Main {
    public abstract class Transport {
        public abstract void init(Scanner scanner);

        public abstract int getLoadCapacity();

        public static int matchint(String match) {
            Pattern pat = Pattern.compile("[-]?[0-9]+(.[0-9]+)?");
            Matcher matcher = pat.matcher(match);
            if (matcher.find()) {
                return Integer.parseInt(matcher.group());
            }
            return -1;
        }

    }


    class Cars extends Transport {

        String mark;
        String number;
        int speed;
        int capacity;

        @Override
        public void init(Scanner scanner) {

            System.out.println("Введите марку");
            mark = scanner.next();


            System.out.println("Введите номер");
            number = scanner.next();

            System.out.println("Введите скорость");
            speed = scanner.nextInt();

            System.out.println("Введите грузоподъемность");
            capacity = scanner.nextInt();
        }


        public int getLoadCapacity() {
            return capacity;
        }

        @Override
        public String toString() {
            return "Марка: " + mark + " Номер " + number + " Скорость " + speed + " Грузоподъемность " + capacity;
        }


    }


    class Moto extends Transport {


        String mark;
        String number;
        int speed;
        int capacity;
        int stroller;

        @Override
        public void init(Scanner scanner) {
            System.out.println("Введите марку");
            mark = scanner.next();

            System.out.println("Введите номер");
            number = scanner.next();

            System.out.println("Введите скорость");
            speed = scanner.nextInt();

            System.out.println("Введите грузоподъемность");
            capacity = scanner.nextInt();

            System.out.println("Коляска есть? (1/0)");
            stroller = scanner.nextInt();

            if (stroller == 0)
                capacity = 0;

        }


        public int getLoadCapacity() {


            return capacity;
        }

        @Override
        public String toString() {
            return "Марка: " + mark + " Номер " + number + " Скорость " + speed + " Грузоподъемность " + capacity + " Коляска: " + stroller;
        }

    }


    class Truck extends Transport {

        String mark;
        String number;
        int speed;
        int capacity;
        int trailer;

        @Override
        public void init(Scanner scanner) {
            System.out.println("Введите марку");
            mark = scanner.next();

            System.out.println("Введите номер");
            number = scanner.next();

            System.out.println("Введите скорость");
            speed = scanner.nextInt();

            System.out.println("Введите грузоподъемность");
            capacity = scanner.nextInt();

            System.out.println("Прицеп есть? (1/0)");
            trailer = scanner.nextInt();

            if (trailer == 1)
                capacity *= 2;

        }


        public int getLoadCapacity() {


            return capacity;
        }

        @Override
        public String toString() {
            return "Марка: " + mark + " Номер " + number + " Скорость " + speed + " Грузоподъемность " + capacity + " Прицеп: " + trailer;
        }

    }
}


