package ru.bstu.itz51.Shulpekov.lab3;

import java.util.Scanner;
import java.io.*;

public class lab3 {

    public static void main(String [] args) {


        Scanner scanner = new Scanner(System.in);

        System.out.println("Введите количество транспорных средств:");
        int kol = Transport.matchint(scanner.next());
        int type;
        int i = 0;
        int max_i = 0;
        int max = 0;
        Transport [] t = new Transport[10];


        System.out.println(kol);



        for (i = 0; i < kol; i++) {

            System.out.println("Введите тип транспортного средства");
            System.out.println("1 - легковой, 2 - мото, 3 - грузовой");

            type = scanner.nextInt();

            switch(type) {

                case 1:
                    Cars car = new Cars();
                    car.init(scanner);
                    t[i] = car;
                    break;

                case 2:
                    Moto moto = new Moto();
                    moto.init(scanner);
                    t[i] = moto;
                    break;

                case 3:
                    Truck truck = new Truck();
                    truck.init(scanner);
                    t[i] = truck;
                    break;
            }



        }


        for (i = 0; i < kol; i++) {

            if (t[i].getLoadCapacity() > max) {
                max = t[i].getLoadCapacity();
                max_i = i;
            }
        }

        System.out.println(t[max_i].toString());

        scanner.close();

    }

}
