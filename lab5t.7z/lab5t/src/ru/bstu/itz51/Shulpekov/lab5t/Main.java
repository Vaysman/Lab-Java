//package ru.bstu.itz51.Shulpekov.lab5t;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.*;
import java.util.*;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;


import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.io.FileInputStream;

import java.io.File;
import java.util.Scanner;

public class Main {
    private static Connection conn;
    private static Statement stmt;
    private static ResultSet rs;
    static String con;
    static String path;
    static int l_id = 0;
    static String url;
    static String xmlpath;

    public static void main(String[] args) {

        Properties prop = new Properties();
        try {
            //обращение к файлу и получение данных
            FileInputStream fis = new FileInputStream("1.properties");
            prop.load(fis);
            // взятие свойства и преобразование в необходимую кодировку
            url = new String(prop.getProperty("con").getBytes("ISO8859-1"));
            xmlpath = new String(prop.getProperty("xmlpath").getBytes("ISO8859-1"));

            //печать полученных данных в консоль
            System.out.println("lab: " + url + "\nfio: " + xmlpath);
        } catch (IOException e) {
            System.out.println("Ошибка в программе: файл не найден");
            e.printStackTrace();
        }
        Scanner scanner = new Scanner(System.in);

        int flag = 0;
        int flag2 = 0;
        int flag3 = 0;

        System.out.println("Выберите формат представления " +
                "(1) XML (2) База данных?");
        flag = scanner.nextInt();

        if (flag == 1) {
            System.out.println("Что вы хотите сделать? " +
                    "(1) Добавить, (2) Редактировать, (3) Удалить запись или (4) Просмотреть запись?");
            flag2 = scanner.nextInt();
            if (flag2 == 1) {
                System.out.println("Для добавления записи введите следующие данные! ");
                //System.out.println("id:\n");
                //int id = scanner.nextInt();
                System.out.println("Название группы:\n");
                String name = scanner.next();
                System.out.println("Жанр исполнения:\n");
                String genre = scanner.next();
                System.out.println("Кол-во человек:\n");
                int number = scanner.nextInt();
                System.out.println("Кол-во альбомов:\n");
                int num_albums = scanner.nextInt();
                System.out.println("Страна:\n");
                String country = scanner.next();
                insertXML(name, genre, number, num_albums, country);
            }

        } else if (flag == 2) {

            System.out.println("Что вы хотите сделать? " +
                    "(1) Добавить, (2) Редактировать, (3) Удалить запись или (4) Просмотреть запись?");
            flag2 = scanner.nextInt();

            if (flag2 == 1) {
                System.out.println("Для добавления записи введите следующие данные! ");
                //System.out.println("id:\n");
                //int id = scanner.nextInt();
                System.out.println("Название группы:\n");
                String name = scanner.next();
                System.out.println("Жанр исполнения:\n");
                String genre = scanner.next();
                System.out.println("Кол-во человек:\n");
                int number = scanner.nextInt();
                System.out.println("Кол-во альбомов:\n");
                int num_albums = scanner.nextInt();
                System.out.println("Страна:\n");
                String country = scanner.next();
                insert(name, genre, number, num_albums, country);
            } else if (flag2 == 2) {
                System.out.println("Для редактирования записи введите следующие данные! ");
                System.out.println("id записи:\n");
                int id = scanner.nextInt();
                System.out.println("Название редактируемого поля:\n");
                String pole = scanner.next();
                System.out.println("Новое значение редактируемого поля:\n");
                String new_val = scanner.next();
                update(id, pole, new_val);
            } else if (flag2 == 3) {
                System.out.println("Для удаления записи введите id данной записи! ");
                int id = scanner.nextInt();
                delete(id);
            } else if (flag2 == 4) {
                System.out.println("Вывести отдельную запись(1) или вывести все записи(2) ? ");
                flag3 = scanner.nextInt();
                if (flag3 == 1) {
                    System.out.println("Введите id записи. ");
                    int id = scanner.nextInt();
                    showOne(id);
                } else if (flag3 == 2) {
                    showAll(1);
                    getLastId();
                }
            }
        }
    }

    ////////////////////////////////////////////
    ///// Добавление новой записи в БД /////////
    ////////////////////////////////////////////

    public static void insert(String name, String genre, int number, int num_albums, String country) {

        try {
            // db parameters
            String url = con;
            // create a connection to the database
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/musicians", "root", "");

            stmt = conn.createStatement();

            stmt.executeUpdate("INSERT INTO group_mus (name, genre, number, num_albums, country) " +
                    " VALUES ('" + name + "','" + genre + "', '" + number + "','" + num_albums + "', '" + country + "')");

            System.out.println("Поздравляем! Запись была успешно добавлена.\n");
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        } finally {
            try {
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException ex) {
                System.out.println(ex.getMessage());
            }
        }

    }

    ////////////////////////////////////////////
    ///////// Обновление записи в БД ///////////
    ////////////////////////////////////////////

    public static void update(int id, String pole, String new_val) {

        try {
            // db parameters
            String url = con;
            // create a connection to the database
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/musicians", "root", "");

            stmt = conn.createStatement();

            stmt.executeUpdate("Update group_mus Set " + pole + " = '" + new_val + "' Where id=" + id);
            System.out.println("Поздравляем! Запись была успешно обновлена.\n");
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        } finally {
            try {
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException ex) {
                System.out.println(ex.getMessage());
            }
        }

    }

    ////////////////////////////////////////////
    ///////// Удаление записи из БД ////////////
    ////////////////////////////////////////////

    public static void delete(int id) {

        try {
            // db parameters
            String url = con;
            // create a connection to the database
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/musicians", "root", "");

            stmt = conn.createStatement();

            stmt.executeUpdate("DELETE FROM group_mus WHERE id = '" + id + "'");
            System.out.println("Поздравляем! Запись была успешно удалена.\n");
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        } finally {
            try {
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException ex) {
                System.out.println(ex.getMessage());
            }
        }

    }

    ////////////////////////////////////////////
    /////// Показываем одну запись из БД ///////
    ////////////////////////////////////////////

    public static void showOne(int id) {

        try {
            // db parameters
            String url = con;
            // create a connection to the database
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/musicians", "root", "");

            stmt = conn.createStatement();

            rs = stmt.executeQuery("SELECT * FROM group_mus WHERE id = '" + id + "'");

            while (rs.next()) {
                Integer f1 = rs.getInt("id");
                String f2 = rs.getString("name");
                String f3 = rs.getString("genre");
                Integer f4 = rs.getInt("number");
                String f5 = rs.getString("num_albums");
                String f6 = rs.getString("country");

                System.out.println("id: " + f1 + "\nНазвание группы: " + f2
                        + "\nЖанр исполнения: " + f5 + "\nКол-во человек: " + f3 + "\nКол-во альбомов: " + f4 +
                        "\nСтрана: " + f6 + "\n================== \n\n");
            }

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        } finally {
            try {
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException ex) {
                System.out.println(ex.getMessage());
            }
        }

    }

    ////////////////////////////////////////////
    /////// Показываем все записи из БД ////////
    ////////////////////////////////////////////
    public static void showAll(int flag_id) {

        try {
            // db parameters
            String url = con;
            // create a connection to the database
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/musicians", "root", "");
            //System.out.println("Соединение с Базой Данных было установлено!");

            stmt = conn.createStatement();

            rs = stmt.executeQuery("SELECT * FROM group_mus");

            while (rs.next()) {
                Integer f1 = rs.getInt("id");
                String f2 = rs.getString("name");
                String f3 = rs.getString("genre");
                Integer f4 = rs.getInt("number");
                String f5 = rs.getString("num_albums");
                String f6 = rs.getString("country");
                l_id = f1;
                if(flag_id != 0)
                System.out.println("id: " + f1 + "\nНазвание группы: " + f2
                        + "\nЖанр исполнения: " + f5 + "\nКол-во человек: " + f3 + "\nКол-во альбомов: " + f4 +
                        "\nСтрана: " + f6 + "\n================== \n\n");
            }
            //if(flag_id == 0)
            //System.out.println("id: " + l_id);


        } catch (SQLException e) {
            System.out.println(e.getMessage());
        } finally {
            try {
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException ex) {
                System.out.println(ex.getMessage());
            }
        }
    }


    ////////////////////////////////////////////
    //////// Узнаем последний id записи ////////
    ////////////////////////////////////////////

    public static void getLastId(){
        showAll(0);
    }



    ////////////////////////////////////////////
    ///// Добавление новой записи в XML ////////
    ////////////////////////////////////////////

    public static void insertXML(String name, String genre, int number, int num_albums, String country) {

        File xmlFile = new File(xmlpath);

        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder;

        try {
            builder = factory.newDocumentBuilder();
            Document doc = builder.parse(xmlFile);
            // создаем корневой элемент
            Element rootElement = doc.getDocumentElement();
            // добавляем корневой элемент в объект Document
            //doc.appendChild(rootElement);

            rootElement.appendChild(getMus(doc, name, genre, number, num_albums, country));

            doc.getDocumentElement().normalize();

            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();


            transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "4");
            //получение исходного кода готового документа
            DOMSource source = new DOMSource(doc);

            StreamResult file = new StreamResult(new File(xmlpath));
            //запись данных
            transformer.transform(source, file);
            System.out.println("Добавление успешно завершено!");


        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //////////////////////////////////////////////
    // Метод для создания нового узла XML-файла //
    //////////////////////////////////////////////

    private static Node getMus(Document doc, String name, String genre, int number, int num_albums, String country) {
        Element group = doc.createElement("group");
        getLastId();
        l_id++;
        String ll = String.valueOf(l_id);
        String num = String.valueOf(number);
        String num_al = String.valueOf(num_albums);

        group.setAttribute("id", ll); // устанавливаем атрибут id
        // создаем элементы
        group.appendChild(getMusElements(doc, group, "name", name));
        group.appendChild(getMusElements(doc, group, "genre", genre));
        group.appendChild(getMusElements(doc, group, "number", num));
        group.appendChild(getMusElements(doc, group, "num_albums", num_al));
        group.appendChild(getMusElements(doc, group, "country", country));

        return group;
    }

    ////////////////////////////////////
    // Метод для создания одного узла //
    ////////////////////////////////////

    private static Node getMusElements(Document doc, Element element, String name, String value) {
        Element node = doc.createElement(name);
        node.appendChild(doc.createTextNode(value));
        return node;
    }

}

